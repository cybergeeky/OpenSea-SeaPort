from django.contrib import admin

from .models import Collection

admin.site.register(Collection)
