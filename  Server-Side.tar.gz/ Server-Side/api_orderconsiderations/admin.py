from django.contrib import admin

from .models import OrderConsideration

admin.site.register(OrderConsideration)
