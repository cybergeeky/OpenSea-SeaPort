from django.contrib import admin

from .models import OrderOffer

admin.site.register(OrderOffer)
