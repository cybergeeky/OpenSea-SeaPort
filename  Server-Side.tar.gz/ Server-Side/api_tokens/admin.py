from django.contrib import admin

from .models import Token

admin.site.register(Token)
